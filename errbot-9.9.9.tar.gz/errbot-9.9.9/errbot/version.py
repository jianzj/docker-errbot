# Just the current version of Errbot.
# It is used for deployment on pypi AND for version checking at plugin load time.
VERSION = '9.9.9'  # leave it at 9.9.9 on master until it is branched to a version.
