import inspect
import logging
import sys


def ispydevd():
    for frame in inspect.stack():
        if frame[1].endswith("pydevd.py"):
            return True
    return False


root_logger = logging.getLogger()
logging.getLogger('yapsy').setLevel(logging.INFO)  # this one is way too verbose in debug
logging.getLogger('Rocket.Errors.ThreadPool').setLevel(logging.INFO)  # this one is way too verbose in debug
root_logger.setLevel(logging.INFO)

pydev = ispydevd()
stream = sys.stdout if pydev else sys.stderr
isatty = pydev or stream.isatty()  # force isatty if we are under pydev because it supports coloring anyway.
console_hdlr = logging.StreamHandler(stream)


def get_log_colors(theme_color=None):
    """Return a tuple containing the log format string and a log color dict"""
    if theme_color == 'light':
        text_color_theme = 'white'
    elif theme_color == 'dark':
        text_color_theme = 'black'
    else:  # Anything else produces nocolor
        return (
            "%(name)-25.25s%(reset)s %(message)s%(reset)s",
            {
                'DEBUG': '',
                'INFO': '',
                'WARNING': '',
                'ERROR': '',
                'CRITICAL': '',
            },
        )

    return (
        "%(name)-25.25s%(reset)s %({})s%(message)s%(reset)s".format(text_color_theme),
        {
            'DEBUG': 'cyan',
            'INFO': 'green',
            'WARNING': 'yellow',
            'ERROR': 'red',
            'CRITICAL': 'red',
        }
    )


def format_logs(theme_color=None):
    # if isatty and not True:
    if isatty:
        from colorlog import ColoredFormatter  # noqa
        log_format, colors_dict = get_log_colors(theme_color)
        formatter = ColoredFormatter(
            "%(asctime)s %(log_color)s%(levelname)-8s%(reset)s " +
            log_format,
            datefmt="%H:%M:%S",
            reset=True,
            log_colors=colors_dict,
        )
        console_hdlr.setFormatter(formatter)
    else:
        console_hdlr.setFormatter(logging.Formatter("%(asctime)s %(levelname)-8s %(name)-25s %(message)s"))
    root_logger.addHandler(console_hdlr)
